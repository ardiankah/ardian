NDC LEARNING — THREE-PHASE SEPARATOR FINAL PROJECT
PERTEMUAN 10 / 10

CARA MENJALANKAN (WINDOWS)
1. Ekstrak file ZIP.
2. Buka folder NDC_Separator_Final dengan Visual Studio Code.
3. Instal ekstensi Live Server (Ritwick Dey) bila belum tersedia.
4. Klik kanan index.html > Open with Live Server.
5. Internet harus aktif karena Three.js dimuat dari jsDelivr CDN.

PRAKTIK FINAL
A. Putar dan zoom objek 3D; sembunyikan shell.
B. Klik tag P&ID untuk membaca nilai instrumentasi.
C. Ubah inlet flow dan setpoint; amati tekanan dan level.
D. Pilih Inlet Surge atau Outlet Restriction lalu Apply Scenario.
E. Perhatikan trend, alarm, dan KPI.
F. Klik MANUAL ESD; perhatikan status trip.
G. Klik Reset untuk mengembalikan kondisi awal.
H. Jalankan 30-60 detik lalu Export CSV, buka di Excel.

PUBLIKASI GITHUB PAGES
1. Login ke https://github.com dan buat repository publik, contoh: ndc-separator-simulator.
2. Klik Add file > Upload files; unggah index.html dari folder ini; Commit changes.
3. Buka Settings > Pages.
4. Pada Build and deployment, pilih Deploy from a branch.
5. Branch: main; folder: /(root); klik Save.
6. Tunggu proses deployment; buka URL yang ditampilkan di halaman Pages.
7. Uji 3D, slider, P&ID, ESD, dan ekspor CSV dari link publik.
Catatan: GitHub Pages untuk repository publik mengikuti kebijakan paket GitHub saat ini.

BATASAN TEKNIS
- Model edukasi, bukan digital twin tervalidasi atau perangkat keselamatan lapangan.
- Persamaan tekanan dan level disederhanakan; tidak untuk sizing atau tuning aktual.
- AUTO menggunakan kontrol PI ilustratif; tidak mereplikasi PID/ESD lapangan.
- P&ID adalah skema pelatihan, bukan dokumen desain resmi.
- Logging berlangsung di memori browser; data hilang saat halaman dimuat ulang kecuali diekspor.
- Three.js menggunakan CDN sehingga perlu internet saat membuka aplikasi.
